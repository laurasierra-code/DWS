package Test;

import org.junit.Test;

import Main.Matriz;

import static org.junit.Assert.assertEquals;

public class MatrizTest {
    @Test
    public void testColumnas() {
        Matriz<Integer> matriz = new Matriz<Integer>(2, 3);

        assertEquals(3, matriz.Columnas());
    }

    @Test
    public void testFilas() {
        Matriz<Integer> matriz = new Matriz<Integer>(2, 3);

        assertEquals(2, matriz.Filas());
    }

    @Test
    public void testGet() {
        Matriz<Integer> matriz = new Matriz<Integer>(2, 3);
        matriz.set(0, 0, 5);

        assertEquals((Integer)5, matriz.get(0, 0));
    }

    @Test
    public void testSet() {
        Matriz<Integer> matriz = new Matriz<Integer>(2, 3);

        matriz.set(1, 2, 7);

        assertEquals((Integer)7, matriz.get(1, 2));
    }
}
