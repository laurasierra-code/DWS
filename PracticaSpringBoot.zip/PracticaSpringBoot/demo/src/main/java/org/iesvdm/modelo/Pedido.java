package org.iesvdm.modelo;

import java.time.LocalDate;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pedido {

	private int id;
	private BigDecimal total;
	private LocalDate fecha;
	private int clienteId;
	private int comercialId;
}
