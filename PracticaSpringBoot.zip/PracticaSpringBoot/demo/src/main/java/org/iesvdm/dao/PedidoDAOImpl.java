package org.iesvdm.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.iesvdm.dto.ClienteTotalPedidosDTO;
import org.iesvdm.modelo.Comercial;
import org.iesvdm.modelo.Pedido;
import org.iesvdm.modelo.PedidoDetalle;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class PedidoDAOImpl implements PedidoDAO {

	private final JdbcTemplate jdbcTemplate;

	PedidoDAOImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public synchronized void create(Pedido pedido) {
		String sqlInsert = """
				INSERT INTO pedido (total, fecha, id_cliente, id_comercial)
				VALUES (?, ?, ?, ?)
				""";

		KeyHolder keyHolder = new GeneratedKeyHolder();
		int rows = jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(sqlInsert, new String[] { "id" });
			int index = 1;
			ps.setBigDecimal(index++, pedido.getTotal());
			if (pedido.getFecha() == null) {
				ps.setObject(index++, null);
			} else {
				ps.setDate(index++, Date.valueOf(pedido.getFecha()));
			}
			ps.setInt(index++, pedido.getClienteId());
			ps.setInt(index, pedido.getComercialId());
			return ps;
		}, keyHolder);

		pedido.setId(keyHolder.getKey().intValue());
		log.info("Insertados {} pedidos.", rows);
	}

	@Override
	public List<Pedido> getAll() {
		List<Pedido> pedidos = jdbcTemplate.query(
				"SELECT * FROM pedido",
				(rs, rowNum) -> mapPedido(rs.getInt("id"), rs.getBigDecimal("total"),
						rs.getDate("fecha"), rs.getInt("id_cliente"), rs.getInt("id_comercial")));

		log.info("Devueltos {} pedidos.", pedidos.size());
		return pedidos;
	}

	@Override
	public Optional<Pedido> find(int id) {
		Pedido pedido = jdbcTemplate.query(
				"SELECT * FROM pedido WHERE id = ?",
				(rs, rowNum) -> mapPedido(rs.getInt("id"), rs.getBigDecimal("total"),
						rs.getDate("fecha"), rs.getInt("id_cliente"), rs.getInt("id_comercial")),
				id).stream().findFirst().orElse(null);

		return Optional.ofNullable(pedido);
	}

	@Override
	public List<PedidoDetalle> getAllDetalles() {
		List<PedidoDetalle> pedidos = jdbcTemplate.query("""
				SELECT p.id, p.total, p.fecha, p.id_cliente, p.id_comercial,
				       CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS cliente_nombre,
				       CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS comercial_nombre
				FROM pedido p
				JOIN cliente c ON c.id = p.id_cliente
				JOIN comercial co ON co.id = p.id_comercial
				""",
				(rs, rowNum) -> mapPedidoDetalle(
						rs.getInt("id"),
						rs.getBigDecimal("total"),
						rs.getDate("fecha"),
						rs.getInt("id_cliente"),
						rs.getInt("id_comercial"),
						rs.getString("cliente_nombre"),
						rs.getString("comercial_nombre")));

		log.info("Devueltos {} detalles de pedidos.", pedidos.size());
		return pedidos;
	}

	@Override
	public Optional<PedidoDetalle> findDetalle(int id) {
		PedidoDetalle pedido = jdbcTemplate.query("""
				SELECT p.id, p.total, p.fecha, p.id_cliente, p.id_comercial,
				       CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS cliente_nombre,
				       CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS comercial_nombre
				FROM pedido p
				JOIN cliente c ON c.id = p.id_cliente
				JOIN comercial co ON co.id = p.id_comercial
				WHERE p.id = ?
				""",
				(rs, rowNum) -> mapPedidoDetalle(
						rs.getInt("id"),
						rs.getBigDecimal("total"),
						rs.getDate("fecha"),
						rs.getInt("id_cliente"),
						rs.getInt("id_comercial"),
						rs.getString("cliente_nombre"),
						rs.getString("comercial_nombre")),
				id).stream().findFirst().orElse(null);

		return Optional.ofNullable(pedido);
	}
	@Override
	public List<PedidoDetalle> findByComercialId(int comercialId){
		List<PedidoDetalle> pedidos = jdbcTemplate.query("""
				SELECT p.id, p.total, p.fecha, p.id_cliente, p.id_comercial,
				       CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS cliente_nombre,
				       CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS comercial_nombre
				FROM pedido p
				JOIN cliente c ON c.id = p.id_cliente
				JOIN comercial co ON co.id = p.id_comercial
				WHERE p.id_comercial = ?
				""",
				(rs, rowNum) -> mapPedidoDetalle(
						rs.getInt("id"),
						rs.getBigDecimal("total"),
						rs.getDate("fecha"),
						rs.getInt("id_cliente"),
						rs.getInt("id_comercial"),
						rs.getString("cliente_nombre"),
						rs.getString("comercial_nombre")),
				comercialId);
		log.info("Devueltos {} detalles de pedidos para el comercial con id {}.", pedidos.size(), comercialId);
		return pedidos;
	}

	@Override
	public List<PedidoDetalle> findByClienteId(int clienteId) {
		List<PedidoDetalle> pedidos = jdbcTemplate.query("""
				SELECT p.id, p.total, p.fecha, p.id_cliente, p.id_comercial,
				       CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS cliente_nombre,
				       CONCAT_WS(' ', co.nombre, co.apellido1, co.apellido2) AS comercial_nombre
				FROM pedido p
				JOIN cliente c ON c.id = p.id_cliente
				JOIN comercial co ON co.id = p.id_comercial
				WHERE p.id_cliente = ?
				""",
				(rs, rowNum) -> mapPedidoDetalle(
						rs.getInt("id"),
						rs.getBigDecimal("total"),
						rs.getDate("fecha"),
						rs.getInt("id_cliente"),
						rs.getInt("id_comercial"),
						rs.getString("cliente_nombre"),
						rs.getString("comercial_nombre")),
				clienteId);
		log.info("Devueltos {} detalles de pedidos para el cliente con id {}.", pedidos.size(), clienteId);
		return pedidos;
	}

	@Override
	public List<Comercial> findComercialesByClienteId(int clienteId) {
		List<Comercial> comerciales = jdbcTemplate.query("""
				SELECT DISTINCT co.id, co.nombre, co.apellido1, co.apellido2, co.comisión
				FROM comercial co
				JOIN pedido p ON p.id_comercial = co.id
				WHERE p.id_cliente = ?
				ORDER BY co.nombre, co.apellido1, co.apellido2
				""",
				(rs, rowNum) -> new Comercial(
						rs.getInt("id"),
						rs.getString("nombre"),
						rs.getString("apellido1"),
						rs.getString("apellido2"),
						rs.getObject("comisión", Float.class)),
				clienteId);

		log.info("Devueltos {} comerciales que han realizado pedidos al cliente con id {}.",
				comerciales.size(), clienteId);
		return comerciales;
	}

	@Override
	public List<ClienteTotalPedidosDTO> findClientesConPedidosPorComercial(int comercialId) {
		List<ClienteTotalPedidosDTO> clientes = jdbcTemplate.query("""
				SELECT c.id,
				       CONCAT_WS(' ', c.nombre, c.apellido1, c.apellido2) AS cliente_nombre,
				       SUM(p.total) AS total_pedidos_comercial,
				       (
				       	SELECT SUM(p_general.total)
				       	FROM pedido p_general
				       	WHERE p_general.id_cliente = c.id
				       ) AS total_pedidos_general
				FROM cliente c
				JOIN pedido p
				  ON p.id_cliente = c.id
				 AND p.id_comercial = ?
				WHERE EXISTS (
					SELECT 1
					FROM pedido pedido_comercial
					WHERE pedido_comercial.id_cliente = c.id
					  AND pedido_comercial.id_comercial = ?
				)
				GROUP BY c.id, c.nombre, c.apellido1, c.apellido2
				ORDER BY total_pedidos_comercial DESC, c.nombre, c.apellido1, c.apellido2
				""",
				(rs, rowNum) -> new ClienteTotalPedidosDTO(
						rs.getInt("id"),
						rs.getString("cliente_nombre"),
						rs.getBigDecimal("total_pedidos_comercial"),
						rs.getBigDecimal("total_pedidos_general")),
				comercialId,
				comercialId);

		log.info("Devueltos {} clientes con pedidos del comercial con id {}.", clientes.size(), comercialId);
		return clientes;
	}


	@Override
	public void update(Pedido pedido) {
		int rows = jdbcTemplate.update("""
				UPDATE pedido SET
					total = ?,
					fecha = ?,
					id_cliente = ?,
					id_comercial = ?
				WHERE id = ?
				""",
				pedido.getTotal(),
				pedido.getFecha() == null ? null : Date.valueOf(pedido.getFecha()),
				pedido.getClienteId(),
				pedido.getComercialId(),
				pedido.getId());

		log.info("Update de Pedido con {} registros actualizados.", rows);
	}

	@Override
	public void delete(int id) {
		int rows = jdbcTemplate.update("DELETE FROM pedido WHERE id = ?", id);
		log.info("Delete de Pedido con {} registros eliminados.", rows);
	}

	private Pedido mapPedido(int id, BigDecimal total, Date fecha, int clienteId, int comercialId) {
		return new Pedido(id, total, fecha == null ? null : fecha.toLocalDate(), clienteId, comercialId);
	}

	private PedidoDetalle mapPedidoDetalle(int id, BigDecimal total, Date fecha, int clienteId, int comercialId,
			String clienteNombre, String comercialNombre) {
		return new PedidoDetalle(id, total, fecha == null ? null : fecha.toLocalDate(), clienteId, comercialId,
				clienteNombre, comercialNombre);
	}
}