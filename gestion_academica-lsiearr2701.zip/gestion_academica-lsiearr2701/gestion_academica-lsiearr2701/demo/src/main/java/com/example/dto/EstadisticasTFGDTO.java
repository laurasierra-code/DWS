package com.example.dto;

public class EstadisticasTFGDTO {
    private final double notaMedia;
    private final double notaMaxima;
    private final double notaMinima;
    private final long totalEvaluados;

    public EstadisticasTFGDTO(double notaMedia, double notaMaxima, double notaMinima, long totalEvaluados) {
        this.notaMedia = notaMedia;
        this.notaMaxima = notaMaxima;
        this.notaMinima = notaMinima;
        this.totalEvaluados = totalEvaluados;
    }

    public double getNotaMedia() { return notaMedia; }
    public double getNotaMaxima() { return notaMaxima; }
    public double getNotaMinima() { return notaMinima; }
    public long getTotalEvaluados() { return totalEvaluados; }
}
