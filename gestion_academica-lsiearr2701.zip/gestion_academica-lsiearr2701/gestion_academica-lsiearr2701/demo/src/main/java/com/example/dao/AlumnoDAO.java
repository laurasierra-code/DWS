package com.example.dao;

import java.util.List;

import com.example.modelo.Alumno;

public interface AlumnoDAO {
	List<Alumno> findAll();
	Alumno findById(int id);
	List<Alumno> findAlumnosByGrupoId(int grupoId);
	void save(Alumno alumno);
	void update(Alumno alumno);
	void delete(int id);
}
