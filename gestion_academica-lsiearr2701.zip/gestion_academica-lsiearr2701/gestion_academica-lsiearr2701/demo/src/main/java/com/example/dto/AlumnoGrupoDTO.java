package com.example.dto;

public class AlumnoGrupoDTO {
    private final int id;
    private final String nia;
    private final String nombre;
    private final String apellido1;
    private final String apellido2;
    private final String email;
    private final int grupoId;
    private final String codigoGrupo;
    private final String nombreGrupo;

    public AlumnoGrupoDTO(int id, String nia, String nombre, String apellido1, String apellido2,
            String email, int grupoId, String codigoGrupo, String nombreGrupo) {
        this.id = id;
        this.nia = nia;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.email = email;
        this.grupoId = grupoId;
        this.codigoGrupo = codigoGrupo;
        this.nombreGrupo = nombreGrupo;
    }

    public int getId() { return id; }
    public String getNia() { return nia; }
    public String getNombre() { return nombre; }
    public String getApellido1() { return apellido1; }
    public String getApellido2() { return apellido2; }
    public String getEmail() { return email; }
    public int getGrupoId() { return grupoId; }
    public String getCodigoGrupo() { return codigoGrupo; }
    public String getNombreGrupo() { return nombreGrupo; }
}
