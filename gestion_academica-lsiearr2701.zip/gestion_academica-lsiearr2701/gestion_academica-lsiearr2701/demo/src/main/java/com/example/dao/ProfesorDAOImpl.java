package com.example.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.modelo.Profesor;

@Repository 
public class ProfesorDAOImpl implements ProfesorDAO{

    private final JdbcTemplate jdbcTemplate;

    public ProfesorDAOImpl(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public List<Profesor> findAll() {
        return jdbcTemplate.query("SELECT id, nif, nombre, apellido1, apellido2, departamento, email FROM profesor ORDER BY id",
                (rs, rowNum) -> {
                    Profesor profesor = new Profesor();
                    profesor.setId(rs.getInt("id"));
                    profesor.setNif(rs.getString("nif"));
                    profesor.setNombre(rs.getString("nombre"));
                    profesor.setApellido1(rs.getString("apellido1"));
                    profesor.setApellido2(rs.getString("apellido2"));
                    profesor.setDepartamento(rs.getString("departamento"));
                    profesor.setEmail(rs.getString("email"));
                    return profesor;
                });
    }

    @Override
    public Profesor findById(int id) {
        return jdbcTemplate.query("SELECT id, nif, nombre, apellido1, apellido2, departamento, email FROM profesor WHERE id = ?",
                (rs, rowNum) -> {
                    Profesor profesor = new Profesor();
                    profesor.setId(rs.getInt("id"));
                    profesor.setNif(rs.getString("nif"));
                    profesor.setNombre(rs.getString("nombre"));
                    profesor.setApellido1(rs.getString("apellido1"));
                    profesor.setApellido2(rs.getString("apellido2"));
                    profesor.setDepartamento(rs.getString("departamento"));
                    profesor.setEmail(rs.getString("email"));
                    return profesor;
                }, id).stream().findFirst().orElse(null);
    }

    @Override
    public void save(Profesor profesor) {
        jdbcTemplate.update("INSERT INTO profesor (nif, nombre, apellido1, apellido2, departamento, email) VALUES (?, ?, ?, ?, ?, ?)",
            profesor.getNif(), profesor.getNombre(), profesor.getApellido1(), profesor.getApellido2(),
            profesor.getDepartamento(), profesor.getEmail());
    }

    @Override
    public void update(Profesor profesor) {
        jdbcTemplate.update("UPDATE profesor SET nif = ?, nombre = ?, apellido1 = ?, apellido2 = ?, departamento = ?, email = ? WHERE id = ?",
            profesor.getNif(), profesor.getNombre(), profesor.getApellido1(), profesor.getApellido2(),
            profesor.getDepartamento(), profesor.getEmail(), profesor.getId());
    }

    @Override
    public void delete(int id) {
        jdbcTemplate.update("DELETE FROM profesor WHERE id = ?", id);
    }
  
  
}
