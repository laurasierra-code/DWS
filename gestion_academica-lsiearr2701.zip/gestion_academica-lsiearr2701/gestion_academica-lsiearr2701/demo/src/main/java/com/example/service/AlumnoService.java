package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.dao.AlumnoDAO;
import com.example.modelo.Alumno;

@Service
public class AlumnoService {
        private final AlumnoDAO alumnoDAO;

        public AlumnoService(AlumnoDAO alumnoDAO) {
                this.alumnoDAO = alumnoDAO;
        }

        public List<Alumno> findAll() {
                return alumnoDAO.findAll();
        }

        public Optional<Alumno> findById(int id) {
                return Optional.ofNullable(alumnoDAO.findById(id));
        }

        public List<Alumno> findAlumnosByGrupoId(int grupoId) {
                return alumnoDAO.findAlumnosByGrupoId(grupoId);
        }

        public void save(Alumno alumno) {
                alumnoDAO.save(alumno);
        }

        public void update(Alumno alumno) {
                alumnoDAO.update(alumno);
        }

        public void delete(int id) {
                alumnoDAO.delete(id);
        }
}
