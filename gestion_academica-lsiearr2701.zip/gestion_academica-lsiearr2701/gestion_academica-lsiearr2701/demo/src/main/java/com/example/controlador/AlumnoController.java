package com.example.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.modelo.Alumno;
import com.example.service.AlumnoService;
import com.example.service.GrupoService;

@Controller
@RequestMapping("/alumnos")
public class AlumnoController {
    private final AlumnoService alumnoService;
    private final GrupoService grupoService;

    public AlumnoController(AlumnoService alumnoService, GrupoService grupoService) {
        this.alumnoService = alumnoService;
        this.grupoService = grupoService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("alumnos", alumnoService.findAll());
        model.addAttribute("grupos", grupoService.findAll());
        return "alumnos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        prepararFormulario(model, new Alumno());
        return "alumnos/formulario";
    }

    @PostMapping("/nuevo")
    public String guardar(Alumno alumno) {
        alumnoService.save(alumno);
        return "redirect:/alumnos";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable int id, Model model) {
        prepararFormulario(model, alumnoService.findById(id).orElseThrow());
        return "alumnos/formulario";
    }

    @PostMapping("/editar/{id}")
    public String actualizar(@PathVariable int id, Alumno alumno) {
        alumno.setId(id);
        alumnoService.update(alumno);
        return "redirect:/alumnos";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable int id) {
        alumnoService.delete(id);
        return "redirect:/alumnos";
    }

    private void prepararFormulario(Model model, Alumno alumno) {
        model.addAttribute("alumno", alumno);
        model.addAttribute("grupos", grupoService.findAll());
    }
}
