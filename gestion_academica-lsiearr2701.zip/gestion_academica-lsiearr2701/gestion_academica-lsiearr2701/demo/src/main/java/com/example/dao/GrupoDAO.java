package com.example.dao;

import java.util.List;

import com.example.modelo.Grupo;

public interface GrupoDAO {
	List<Grupo> findAll();
	Grupo findById(int id);
	List<Grupo> findGruposByTutorId(int profesorId);
	void save(Grupo grupo);
	void update(Grupo grupo);
	void delete(int id);
}
