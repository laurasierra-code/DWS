package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.dao.ProfesorDAO;
import com.example.modelo.Profesor;

@Service
public class ProfesorService {
	private final ProfesorDAO profesorDAO;

	public ProfesorService(ProfesorDAO profesorDAO) {
		this.profesorDAO = profesorDAO;
	}

	public List<Profesor> findAll() {
		return profesorDAO.findAll();
	}

	public Optional<Profesor> findById(int id) {
		return Optional.ofNullable(profesorDAO.findById(id));
	}

	public void save(Profesor profesor) {
		profesorDAO.save(profesor);
	}

	public void update(Profesor profesor) {
		profesorDAO.update(profesor);
	}

	public void delete(int id) {
		profesorDAO.delete(id);
	}

}
