package com.example.dao;

import java.util.List;

import com.example.dto.TutoriaDetalleDTO;
import com.example.modelo.TutoriaTFG;

public interface TutoriaTFGDAO {
    List<TutoriaDetalleDTO> findByProfesorId(int profesorId);
    void saveOrUpdate(TutoriaTFG tutoria);
}
