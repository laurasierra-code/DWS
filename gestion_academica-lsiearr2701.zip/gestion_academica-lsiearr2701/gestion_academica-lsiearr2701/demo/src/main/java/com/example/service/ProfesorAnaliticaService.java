package com.example.service;

import java.util.List;
import java.util.Map;
import java.util.Comparator;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.example.dto.AlumnoGrupoDTO;
import com.example.dto.ProfesorDetalleDTO;
import com.example.dto.ResumenGrupoDTO;
import com.example.modelo.Alumno;
import com.example.modelo.Grupo;
import com.example.modelo.Profesor;

@Service
public class ProfesorAnaliticaService {
    private final GrupoService grupoService;
    private final AlumnoService alumnoService;

    public ProfesorAnaliticaService(GrupoService grupoService, AlumnoService alumnoService) {
        this.grupoService = grupoService;
        this.alumnoService = alumnoService;
    }

    public ProfesorDetalleDTO crearDetalle(Profesor profesor) {
        List<Grupo> gruposTutorizados = grupoService.findGruposByTutorId(profesor.getId());

        List<AlumnoGrupoDTO> alumnos = gruposTutorizados.stream()
            .flatMap(grupo -> alumnoService.findAlumnosByGrupoId(grupo.getId()).stream()
                .map(alumno -> crearAlumnoGrupo(alumno, grupo)))
            .sorted(Comparator.comparing(AlumnoGrupoDTO::getApellido1,
                    Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER))
                .thenComparing(AlumnoGrupoDTO::getApellido2,
                    Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER))
                .thenComparing(AlumnoGrupoDTO::getNombre,
                    Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)))
            .toList();

        Map<Integer, Long> alumnosPorGrupo = alumnos.stream()
            .collect(Collectors.groupingBy(AlumnoGrupoDTO::getGrupoId, Collectors.counting()));

        List<ResumenGrupoDTO> resumenGrupos = gruposTutorizados.stream()
            .map(grupo -> new ResumenGrupoDTO(
                grupo.getCodigo(),
                alumnosPorGrupo.getOrDefault(grupo.getId(), 0L)))
            .toList();

        int totalGrupos = (int) gruposTutorizados.stream().count();
        int totalAlumnos = alumnos.stream().mapToInt(alumno -> 1).sum();

        return new ProfesorDetalleDTO(
            profesor.getId(),
            profesor.getNif(),
            nombreCompleto(profesor),
            profesor.getDepartamento(),
            profesor.getEmail(),
            resumenGrupos,
            alumnos,
            totalGrupos,
            totalAlumnos);
        }

        private AlumnoGrupoDTO crearAlumnoGrupo(Alumno alumno, Grupo grupo) {
        return new AlumnoGrupoDTO(
            alumno.getId(),
            alumno.getNia(),
            alumno.getNombre(),
            alumno.getApellido1(),
            alumno.getApellido2(),
            alumno.getEmail(),
            grupo.getId(),
            grupo.getCodigo(),
            grupo.getNombre());
        }

        private String nombreCompleto(Profesor profesor) {
        return String.join(" ", profesor.getNombre(), profesor.getApellido1(),
            profesor.getApellido2() == null ? "" : profesor.getApellido2()).trim();
        }
    }
