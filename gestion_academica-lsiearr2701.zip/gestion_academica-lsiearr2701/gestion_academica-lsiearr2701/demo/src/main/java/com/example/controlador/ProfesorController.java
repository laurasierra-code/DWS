package com.example.controlador;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.dto.TutoriaDetalleDTO;
import com.example.modelo.Profesor;
import com.example.modelo.TutoriaTFG;
import com.example.service.AlumnoService;
import com.example.service.ProfesorAnaliticaService;
import com.example.service.ProfesorService;
import com.example.service.TutoriaTFGService;

@Controller
@RequestMapping("/profesores")
public class ProfesorController {
    private final ProfesorService profesorService;
    private final ProfesorAnaliticaService profesorAnaliticaService;
    private final AlumnoService alumnoService;
    private final TutoriaTFGService tutoriaTFGService;

    public ProfesorController(ProfesorService profesorService, ProfesorAnaliticaService profesorAnaliticaService,
            AlumnoService alumnoService, TutoriaTFGService tutoriaTFGService) {
        this.profesorService = profesorService;
        this.profesorAnaliticaService = profesorAnaliticaService;
        this.alumnoService = alumnoService;
        this.tutoriaTFGService = tutoriaTFGService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("profesores", profesorService.findAll());
        return "profesores/lista";
    }

    @GetMapping("/{id}")
    public String detalle(@PathVariable int id, Model model) {
        Optional<Profesor> profesorOpt = profesorService.findById(id);

        if (profesorOpt.isEmpty()) {
            return "redirect:/profesores";
        }

        model.addAttribute("detalle", profesorAnaliticaService.crearDetalle(profesorOpt.get()));
        List<TutoriaDetalleDTO> tutorias = tutoriaTFGService.findByProfesorId(id);
        model.addAttribute("tutorias", tutorias);
        model.addAttribute("estadisticasTFG", tutoriaTFGService.calcularEstadisticas(tutorias));
        model.addAttribute("alumnosDisponibles", alumnoService.findAll());
        TutoriaTFG nuevaTutoria = new TutoriaTFG();
        nuevaTutoria.setProfesorId(id);
        model.addAttribute("nuevaTutoria", nuevaTutoria);
        return "profesores/detalle-profesor";
    }

    @PostMapping("/{id}/tutorias")
    public String guardarTutoria(@PathVariable int id, TutoriaTFG tutoria) {
        tutoria.setProfesorId(id);
        tutoriaTFGService.saveOrUpdate(tutoria);
        return "redirect:/profesores/" + id;
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("profesor", new Profesor());
        return "profesores/formulario";
    }

    @PostMapping("/nuevo")
    public String guardar(Profesor profesor) {
        profesorService.save(profesor);
        return "redirect:/profesores";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable int id, Model model) {
        model.addAttribute("profesor", profesorService.findById(id).orElseThrow());
        return "profesores/formulario";
    }

    @PostMapping("/editar/{id}")
    public String actualizar(@PathVariable int id, Profesor profesor) {
        profesor.setId(id);
        profesorService.update(profesor);
        return "redirect:/profesores";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable int id) {
        profesorService.delete(id);
        return "redirect:/profesores";
    }
}
