package com.example.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.modelo.Alumno;

@Repository 
public class AlumnoDAOImpl implements AlumnoDAO{
    
    private final JdbcTemplate jdbcTemplate;

    public AlumnoDAOImpl(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Alumno> findAll() {
        return jdbcTemplate.query("SELECT id, nia, nombre, apellido1, apellido2, email, grupo_id FROM alumno ORDER BY id",
            (rs, rowNum) -> mapAlumno(rs));
    }

    @Override
    public Alumno findById(int id) {
        return jdbcTemplate.query("SELECT id, nia, nombre, apellido1, apellido2, email, grupo_id FROM alumno WHERE id = ?",
            (rs, rowNum) -> mapAlumno(rs), id).stream().findFirst().orElse(null);
    }

    @Override
    public List<Alumno> findAlumnosByGrupoId(int grupoId) {
        return jdbcTemplate.query("SELECT id, nia, nombre, apellido1, apellido2, email, grupo_id FROM alumno WHERE grupo_id = ? ORDER BY id",
            (rs, rowNum) -> mapAlumno(rs), grupoId);
    }

    @Override
    public void save(Alumno alumno) {
        jdbcTemplate.update("INSERT INTO alumno (nia, nombre, apellido1, apellido2, email, grupo_id) VALUES (?, ?, ?, ?, ?, ?)",
            alumno.getNia(), alumno.getNombre(), alumno.getApellido1(), alumno.getApellido2(),
            alumno.getEmail(), alumno.getGrupo_id());
    }

    @Override
    public void update(Alumno alumno) {
        jdbcTemplate.update("UPDATE alumno SET nia = ?, nombre = ?, apellido1 = ?, apellido2 = ?, email = ?, grupo_id = ? WHERE id = ?",
            alumno.getNia(), alumno.getNombre(), alumno.getApellido1(), alumno.getApellido2(),
            alumno.getEmail(), alumno.getGrupo_id(), alumno.getId());
    }

    @Override
    public void delete(int id) {
        jdbcTemplate.update("DELETE FROM alumno WHERE id = ?", id);
    }

    private Alumno mapAlumno(java.sql.ResultSet rs) throws java.sql.SQLException {
        Alumno alumno = new Alumno();
        alumno.setId(rs.getInt("id"));
        alumno.setNia(rs.getString("nia"));
        alumno.setNombre(rs.getString("nombre"));
        alumno.setApellido1(rs.getString("apellido1"));
        alumno.setApellido2(rs.getString("apellido2"));
        alumno.setEmail(rs.getString("email"));
        int grupoId = rs.getInt("grupo_id");
        alumno.setGrupo_id(rs.wasNull() ? null : grupoId);
        return alumno;
    }

   
}
