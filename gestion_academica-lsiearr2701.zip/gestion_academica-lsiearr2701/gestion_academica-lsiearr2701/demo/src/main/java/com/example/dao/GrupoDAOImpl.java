package com.example.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.modelo.Grupo;

@Repository 
public class GrupoDAOImpl implements GrupoDAO{

    private final JdbcTemplate jdbcTemplate;

    public GrupoDAOImpl(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Grupo> findAll() {
        return jdbcTemplate.query("SELECT id, codigo, nombre, curso, tutor_id FROM grupo ORDER BY id",
            (rs, rowNum) -> mapGrupo(rs));
    }

    @Override
    public Grupo findById(int id) {
        return jdbcTemplate.query("SELECT id, codigo, nombre, curso, tutor_id FROM grupo WHERE id = ?",
            (rs, rowNum) -> mapGrupo(rs), id).stream().findFirst().orElse(null);
    }

    @Override
    public List<Grupo> findGruposByTutorId(int profesorId) {
        return jdbcTemplate.query("SELECT id, codigo, nombre, curso, tutor_id FROM grupo WHERE tutor_id = ? ORDER BY id",
            (rs, rowNum) -> mapGrupo(rs), profesorId);
    }

    @Override
    public void save(Grupo grupo) {
        jdbcTemplate.update("INSERT INTO grupo (codigo, nombre, curso, tutor_id) VALUES (?, ?, ?, ?)",
            grupo.getCodigo(), grupo.getNombre(), grupo.getCurso(), grupo.getTutor_id());
    }

    @Override
    public void update(Grupo grupo) {
        jdbcTemplate.update("UPDATE grupo SET codigo = ?, nombre = ?, curso = ?, tutor_id = ? WHERE id = ?",
            grupo.getCodigo(), grupo.getNombre(), grupo.getCurso(), grupo.getTutor_id(), grupo.getId());
    }

    @Override
    public void delete(int id) {
        jdbcTemplate.update("DELETE FROM grupo WHERE id = ?", id);
    }

    private Grupo mapGrupo(java.sql.ResultSet rs) throws java.sql.SQLException {
        Grupo grupo = new Grupo();
        grupo.setId(rs.getInt("id"));
        grupo.setCodigo(rs.getString("codigo"));
        grupo.setNombre(rs.getString("nombre"));
        grupo.setCurso(rs.getInt("curso"));
                int tutorId = rs.getInt("tutor_id");
                grupo.setTutor_id(rs.wasNull() ? null : tutorId);
        return grupo;
    }

    
}
