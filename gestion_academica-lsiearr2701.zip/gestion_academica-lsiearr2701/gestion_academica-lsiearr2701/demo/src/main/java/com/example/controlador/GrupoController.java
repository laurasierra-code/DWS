package com.example.controlador;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.modelo.Grupo;
import com.example.service.GrupoService;
import com.example.service.ProfesorService;

@Controller
@RequestMapping("/grupos")
public class GrupoController {
    private final GrupoService grupoService;
    private final ProfesorService profesorService;

    public GrupoController(GrupoService grupoService, ProfesorService profesorService) {
        this.grupoService = grupoService;
        this.profesorService = profesorService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("grupos", grupoService.findAll());
        model.addAttribute("profesores", profesorService.findAll());
        return "grupos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        prepararFormulario(model, new Grupo());
        return "grupos/formulario";
    }

    @PostMapping("/nuevo")
    public String guardar(Grupo grupo) {
        grupoService.save(grupo);
        return "redirect:/grupos";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable int id, Model model) {
        prepararFormulario(model, grupoService.findById(id).orElseThrow());
        return "grupos/formulario";
    }

    @PostMapping("/editar/{id}")
    public String actualizar(@PathVariable int id, Grupo grupo) {
        grupo.setId(id);
        grupoService.update(grupo);
        return "redirect:/grupos";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable int id) {
        grupoService.delete(id);
        return "redirect:/grupos";
    }

    private void prepararFormulario(Model model, Grupo grupo) {
        model.addAttribute("grupo", grupo);
        model.addAttribute("profesores", profesorService.findAll());
    }
}
