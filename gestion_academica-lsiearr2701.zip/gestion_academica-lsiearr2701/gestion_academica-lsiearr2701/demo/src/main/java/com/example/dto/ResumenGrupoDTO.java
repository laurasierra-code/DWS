package com.example.dto;

public class ResumenGrupoDTO {
    private final String codigoGrupo;
    private final long totalAlumnos;

    public ResumenGrupoDTO(String codigoGrupo, long totalAlumnos) {
        this.codigoGrupo = codigoGrupo;
        this.totalAlumnos = totalAlumnos;
    }

    public String getCodigoGrupo() { return codigoGrupo; }
    public long getTotalAlumnos() { return totalAlumnos; }
}
