package com.example.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.example.dto.TutoriaDetalleDTO;
import com.example.modelo.TutoriaTFG;

@Repository
public class TutoriaTFGDAOImpl implements TutoriaTFGDAO {
    private final JdbcTemplate jdbcTemplate;

    public TutoriaTFGDAOImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<TutoriaDetalleDTO> findByProfesorId(int profesorId) {
        String sql = """
                SELECT t.profesor_id,
                       CONCAT_WS(' ', p.nombre, p.apellido1, p.apellido2) AS nombre_profesor,
                       t.alumno_id,
                       CONCAT_WS(' ', a.nombre, a.apellido1, a.apellido2) AS nombre_alumno,
                       g.codigo AS codigo_grupo,
                       t.nota,
                       t.observaciones
                FROM profesor_has_alumno t
                JOIN profesor p ON p.id = t.profesor_id
                JOIN alumno a ON a.id = t.alumno_id
                LEFT JOIN grupo g ON g.id = a.grupo_id
                WHERE t.profesor_id = ?
                ORDER BY a.apellido1, a.apellido2, a.nombre
                """;

        return jdbcTemplate.query(sql, (rs, rowNum) -> new TutoriaDetalleDTO(
                rs.getInt("profesor_id"),
                rs.getString("nombre_profesor"),
                rs.getInt("alumno_id"),
                rs.getString("nombre_alumno"),
                rs.getString("codigo_grupo"),
                rs.getBigDecimal("nota"),
                rs.getString("observaciones")), profesorId);
    }

    @Override
    public void saveOrUpdate(TutoriaTFG tutoria) {
        String sql = """
                INSERT INTO profesor_has_alumno (profesor_id, alumno_id, nota, observaciones)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    nota = VALUES(nota),
                    observaciones = VALUES(observaciones)
                """;
        jdbcTemplate.update(sql, tutoria.getProfesorId(), tutoria.getAlumnoId(),
                tutoria.getNota(), tutoria.getObservaciones());
    }
}
