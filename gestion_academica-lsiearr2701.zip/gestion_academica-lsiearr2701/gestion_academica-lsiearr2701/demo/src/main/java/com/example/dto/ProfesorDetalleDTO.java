package com.example.dto;

import java.util.List;

public class ProfesorDetalleDTO {
    private final int id;
    private final String nif;
    private final String nombreCompleto;
    private final String departamento;
    private final String email;
        private final List<ResumenGrupoDTO> resumenGrupos;
        private final List<AlumnoGrupoDTO> alumnos;
    private final int totalGrupos;
    private final int totalAlumnos;

    public ProfesorDetalleDTO(int id, String nif, String nombreCompleto, String departamento,
            String email, List<ResumenGrupoDTO> resumenGrupos, List<AlumnoGrupoDTO> alumnos,
            int totalGrupos, int totalAlumnos) {
        this.id = id;
        this.nif = nif;
        this.nombreCompleto = nombreCompleto;
        this.departamento = departamento;
        this.email = email;
        this.resumenGrupos = resumenGrupos;
        this.alumnos = alumnos;
        this.totalGrupos = totalGrupos;
        this.totalAlumnos = totalAlumnos;
    }

    public int getId() { return id; }
    public String getNif() { return nif; }
    public String getNombreCompleto() { return nombreCompleto; }
    public String getDepartamento() { return departamento; }
    public String getEmail() { return email; }
    public List<ResumenGrupoDTO> getResumenGrupos() { return resumenGrupos; }
    public List<AlumnoGrupoDTO> getAlumnos() { return alumnos; }
    public int getTotalGrupos() { return totalGrupos; }
    public int getTotalAlumnos() { return totalAlumnos; }
}
