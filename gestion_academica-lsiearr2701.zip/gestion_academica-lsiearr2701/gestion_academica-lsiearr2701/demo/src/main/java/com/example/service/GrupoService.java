package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.dao.GrupoDAO;
import com.example.modelo.Grupo;

@Service
public class GrupoService {
	private final GrupoDAO grupoDAO;

	public GrupoService(GrupoDAO grupoDAO) {
		this.grupoDAO = grupoDAO;
	}

	public List<Grupo> findAll() {
		return grupoDAO.findAll();
	}

	public Optional<Grupo> findById(int id) {
		return Optional.ofNullable(grupoDAO.findById(id));
	}

	public List<Grupo> findGruposByTutorId(int profesorId) {
		return grupoDAO.findGruposByTutorId(profesorId);
	}

	public void save(Grupo grupo) {
		grupoDAO.save(grupo);
	}

	public void update(Grupo grupo) {
		grupoDAO.update(grupo);
	}

	public void delete(int id) {
		grupoDAO.delete(id);
	}

}
