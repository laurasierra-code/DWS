package com.example.modelo;

public class Alumno {

    private int id;
    private String nia;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String email;
    private Integer grupo_id;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNia() { return nia; }
    public void setNia(String nia) { this.nia = nia; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellido1() { return apellido1; }
    public void setApellido1(String apellido1) { this.apellido1 = apellido1; }
    public String getApellido2() { return apellido2; }
    public void setApellido2(String apellido2) { this.apellido2 = apellido2; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Integer getGrupo_id() { return grupo_id; }
    public void setGrupo_id(Integer grupo_id) { this.grupo_id = grupo_id; }
}
