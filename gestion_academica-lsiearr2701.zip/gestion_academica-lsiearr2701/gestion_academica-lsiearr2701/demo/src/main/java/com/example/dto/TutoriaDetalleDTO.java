package com.example.dto;

import java.math.BigDecimal;

public class TutoriaDetalleDTO {
    private final int profesorId;
    private final String nombreCompletoProfesor;
    private final int alumnoId;
    private final String nombreCompletoAlumno;
    private final String codigoGrupo;
    private final BigDecimal nota;
    private final String observaciones;

    public TutoriaDetalleDTO(int profesorId, String nombreCompletoProfesor, int alumnoId,
            String nombreCompletoAlumno, String codigoGrupo, BigDecimal nota, String observaciones) {
        this.profesorId = profesorId;
        this.nombreCompletoProfesor = nombreCompletoProfesor;
        this.alumnoId = alumnoId;
        this.nombreCompletoAlumno = nombreCompletoAlumno;
        this.codigoGrupo = codigoGrupo;
        this.nota = nota;
        this.observaciones = observaciones;
    }

    public int getProfesorId() { return profesorId; }
    public String getNombreCompletoProfesor() { return nombreCompletoProfesor; }
    public int getAlumnoId() { return alumnoId; }
    public String getNombreCompletoAlumno() { return nombreCompletoAlumno; }
    public String getCodigoGrupo() { return codigoGrupo; }
    public BigDecimal getNota() { return nota; }
    public String getObservaciones() { return observaciones; }
}
