package com.example.service;

import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.example.dao.TutoriaTFGDAO;
import com.example.dto.EstadisticasTFGDTO;
import com.example.dto.TutoriaDetalleDTO;
import com.example.modelo.TutoriaTFG;

@Service
public class TutoriaTFGService {
    private final TutoriaTFGDAO tutoriaTFGDAO;

    public TutoriaTFGService(TutoriaTFGDAO tutoriaTFGDAO) {
        this.tutoriaTFGDAO = tutoriaTFGDAO;
    }

    public List<TutoriaDetalleDTO> findByProfesorId(int profesorId) {
        return tutoriaTFGDAO.findByProfesorId(profesorId);
    }

    public void saveOrUpdate(TutoriaTFG tutoria) {
        tutoriaTFGDAO.saveOrUpdate(tutoria);
    }

    public EstadisticasTFGDTO calcularEstadisticas(List<TutoriaDetalleDTO> tutorias) {
        var notas = tutorias.stream()
                .map(TutoriaDetalleDTO::getNota)
                .filter(Objects::nonNull)
                .mapToDouble(Number::doubleValue)
                .summaryStatistics();

        if (notas.getCount() == 0) {
            return new EstadisticasTFGDTO(0.0, 0.0, 0.0, 0);
        }

        return new EstadisticasTFGDTO(
                notas.getAverage(),
                notas.getMax(),
                notas.getMin(),
                notas.getCount());
    }
}
