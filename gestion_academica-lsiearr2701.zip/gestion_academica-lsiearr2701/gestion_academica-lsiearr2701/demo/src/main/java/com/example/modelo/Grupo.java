package com.example.modelo;

public class Grupo {
    private int id;
    private String codigo;
    private String nombre;
    private int curso;
    private Integer tutor_id;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getCurso() { return curso; }
    public void setCurso(int curso) { this.curso = curso; }
    public Integer getTutor_id() { return tutor_id; }
    public void setTutor_id(Integer tutor_id) { this.tutor_id = tutor_id; }
}
