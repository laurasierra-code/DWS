package com.example.dao;

import java.util.List;

import com.example.modelo.Profesor;

public interface ProfesorDAO {
    List<Profesor> findAll();
    Profesor findById(int id);
    void save(Profesor profesor);
    void update(Profesor profesor);
    void delete(int id);
}
