USE gestion_academica;
DROP TABLE IF EXISTS profesor_has_alumno;

CREATE TABLE profesor_has_alumno (
    profesor_id INT UNSIGNED NOT NULL,
    alumno_id INT UNSIGNED NOT NULL,
    nota DECIMAL(4,2) NULL,
    observaciones VARCHAR(500),

    PRIMARY KEY (profesor_id, alumno_id),

    CONSTRAINT fk_tutoria_profesor
        FOREIGN KEY (profesor_id)
        REFERENCES profesor(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    CONSTRAINT fk_tutoria_alumno
        FOREIGN KEY (alumno_id)
        REFERENCES alumno(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB;